---
title: 'Computer Setup'
author: 'Jared Sackett'
date: '17:00 04-02-2019'
---

This is an overview of my computer setup. Enjoy, and feel free to comment or ask questions!

![Fake Busy 1](FakeBusy1.jpg)

