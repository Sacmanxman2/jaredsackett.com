---
title: About
author: 'Jared Sackett'
date: '18:38 25-01-2019'
---

Hello! Welcome to my site.

I am a Christian, IT student, musician, and lifelong learner. I try my best to overthink everthing, and I have way too many hobbies.

My main goal on this site is to provide advice and work through ideas regarding Christianity, Productivity, Philosophy, Technology, Geekery, and especially when some or all of those intersect. Sometimes I'll take it really seriously, like with my post on Science and Christianity's relationship. Other times I'll try and let my goofy personality out more. This usually involves puns, references, and GIFs (which I will forever insist should be pronounced with a hard "G" as in "Godfather"). 