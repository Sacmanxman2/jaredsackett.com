---
title: 'Mandatory First Post!'
author: 'Jared Sackett'
date: '17:15 06-11-2017'
---

So, I suppose this is the first post I’ll ever make. I’ve decided to make this site as an outlet for various thoughts I have, and to create a place for discussion regarding those. I plan to put some sort of comments system on here, but we’ll see what I can do. I may just recommend responding to what I put on here on your own blog, as I plan to respond to others here.

Aside from various rants and articles to discuss, I’ll occasionally be doing various productivity experiments and trying various things, all of which I’ll put on here for your entertainment!