---
title: Blog
published: false
date: '18:37 25-01-2019'
author: 'Jared Sackett'
content:
    items: '@self.children'
    order:
        by: date
        dir: desc
    limit: 10
    pagination: true
---

