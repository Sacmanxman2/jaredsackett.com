<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class MyTheme extends Theme
{
    // Access plugin events in this class
}
